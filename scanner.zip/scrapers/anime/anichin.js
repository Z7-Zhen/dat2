const axios = require("axios");
const cheerio = require("cheerio");
const https = require("https");

/**
 * Ambil jadwal update Donghua dari Anichin
 * @returns {Promise<{status: boolean, total_days?: number, schedule?: any[], message?: string}>}
 */
async function getDonghuaUpdate() {
  try {
    // 🧠 Agent HTTPS — abaikan error SSL (bisa dihapus kalau server kamu sudah punya sertifikat CA lengkap)
    const httpsAgent = new https.Agent({
      rejectUnauthorized: false,
    });

    const response = await axios.get("https://anichin.watch/schedule/", {
      httpsAgent, // ⬅️ tambah ini agar SSL error tidak muncul
      headers: {
        "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Accept-Language": "en-US,en;q=0.9",
        Referer: "https://anichin.watch/",
        "Cache-Control": "no-cache",
      },
      timeout: 15000, // ⏳ timeout 15 detik
      validateStatus: (status) => status < 500, // hanya error kalau 5xx
    });

    if (response.status !== 200) {
      return {
        status: false,
        message: `Gagal mengambil data (status: ${response.status})`,
      };
    }

    const $ = cheerio.load(response.data);
    const result = [];

    $(".schedulepage").each((_, el) => {
      const day = $(el).find("h3").text().trim();
      const donghuaList = [];

      $(el)
        .find(".bs")
        .each((__, ev) => {
          const title = $(ev).find(".tt").text().trim();
          const img = $(ev).find("img").attr("src") || "";
          const eps = $(ev).find(".bt .sb").text().trim() || "-";
          const time = $(ev).find(".bt .epx").text().trim() || "-";

          if (title) donghuaList.push({ title, img, eps, time });
        });

      if (day && donghuaList.length > 0) {
        result.push({ day, donghua: donghuaList });
      }
    });

    if (result.length === 0) {
      return {
        status: false,
        message:
          "Tidak ada data yang berhasil diambil. Mungkin struktur situs Anichin berubah.",
      };
    }

    return {
      status: true,
      total_days: result.length,
      schedule: result,
    };
  } catch (error) {
    console.error("❌ Error getDonghuaUpdate:", error.message);

    let message = error.message;
    if (error.code === "ECONNABORTED") {
      message = "Permintaan timeout, coba lagi nanti.";
    } else if (error.message.includes("certificate")) {
      message = "Gagal memverifikasi sertifikat SSL situs Anichin.";
    }

    return { status: false, message };
  }
}

module.exports = { getDonghuaUpdate };