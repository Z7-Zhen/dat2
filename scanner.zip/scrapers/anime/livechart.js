const axios = require('axios')
const cheerio = require('cheerio')

async function getUpdate(date = new Date().toISOString().split('T')[0]) {
    try {
        let { data } = await axios.get(`https://www.livechart.me/schedule?date=${date}`)
        const $ = cheerio.load(data)
        const lc = $('.lc-timetable')
        let result = []
        lc.find('.lc-placeholder').remove()
        lc.find('.lc-timetable-day').each((i, el) => {
            result.push({
                day: $(el).find('.lc-timetable-day__heading').text().trim(),
                anime: []
            })
            $(el).find('.hidden').remove()
            $(el).find('.lc-timetable-timeslot').each((j, anime) => {
                const title = $(anime).find('.lc-tt-anime-title').text().trim()
                const time = $(anime).find('.lc-time').text().trim()
                const eps = $(anime).find('.lc-tt-release-label').text().trim()
                result[i].anime.push({ title, time, eps })
            })
        })
        return result
    } catch (e) { 
        return e 
    }
}

// Export supaya bisa dipakai di file lain
module.exports = { getUpdate }

// Contoh testing langsung
if (require.main === module) {
    (async () => {
        let update = await getUpdate('2025-10-01') // format: YYYY-MM-DD or blank for today
        console.log(update)
    })()
}