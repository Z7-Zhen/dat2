const axios = require("axios");
const FormData = require("form-data");
const fs = require("fs");

async function enhanceImage(input) {
  try {
    const form = new FormData();

    if (fs.existsSync(input)) {
      // Jika input adalah file lokal
      form.append("file", fs.createReadStream(input));
    } else if (input.startsWith("http")) {
      // Jika input adalah URL
      form.append("url", input);
    } else {
      throw new Error("Input tidak valid! Harus berupa path file lokal atau URL gambar.");
    }

    const response = await axios.post("https://enhanceit.pro/proxy-1.php", form, {
      headers: form.getHeaders(),
      timeout: 60000, // 60 detik
    });

    if (!response.data?.output_url) {
      throw new Error("Gagal mendapatkan hasil dari enhanceit.pro");
    }

    return {
      status: true,
      original: input,
      enhanced: response.data.output_url,
    };
  } catch (error) {
    console.error("❌ Enhance gagal:", error.message);
    return { status: false, message: error.message };
  }
}

module.exports = { enhanceImage };