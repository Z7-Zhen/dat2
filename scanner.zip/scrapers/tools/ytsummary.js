const axios = require("axios");

async function ytsummarize(url) {
  try {
    // Step 1: buat summary ID sementara (kayak handshake awal)
    await axios.post(
      "https://web.tubeonai.com/api/public/generate-summary",
      {
        summary_id: "temp_E7XkLEEYZnE",
        transcript: "temp transcript",
        detail_level: "detailed",
        tone_name: "neutral",
        language: "en-US",
        user_id: "newsletter_14838",
        prompt: "",
      },
      {
        headers: {
          "Content-Type": "application/json",
          "User-Agent":
            "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36",
          Referer: "https://tubeonai.com/web-article-summarizer/",
        },
      }
    );

    // Step 2: panggil endpoint summary utama
    const summarize = await axios.post(
      "https://web.tubeonai.com/api/public/summarize",
      {
        tool_name: "web-page-summarizer",
        url,
        detail_level: "Detailed",
        tone: "Neutral",
        language: "en-US",
        user_id: "newsletter_14838",
        link_or_id: url,
      },
      {
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
          "User-Agent":
            "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36",
          Referer: "https://tubeonai.com/web-article-summarizer/",
        },
      }
    );

    // Kembalikan hasil summary dari API
    return summarize.data;
  } catch (err) {
    console.error("❌ Gagal summarize:", err.message);
    return { status: false, message: err.response ? err.response.data : err.message };
  }
}

// ✅ Export agar bisa digunakan di file lain
module.exports = { ytsummarize };