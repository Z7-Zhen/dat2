// scrape/tiktok.js
/**
 * Cr : CodeGood
 * Note : Kalo reupload kasih credit plss
 */

const axios = require("axios");

/**
 * Scrape TikTok menggunakan Tikgo API
 * @param {string} url URL TikTok
 * @returns {Promise<Object>} Hasil scrape
 */
async function scrapeTikTok(url) {
  if (!url) throw new Error("URL TikTok harus diisi!");

  try {
    const response = await axios.post(
      "https://tikgo.me/api/tiktok/",
      { url },
      { headers: { "Content-Type": "application/json" } }
    );

    return response.data;
  } catch (err) {
    throw err.response?.data || new Error(err.message || "Gagal scrape TikTok");
  }
}

module.exports = { scrapeTikTok };
