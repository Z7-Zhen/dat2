 
const axios = require('axios');
 
async function pinDown(url) {
  if (!url) throw new Error('url is required');
  const endpoint = 'https://pinterestdownloader.io/frontendService/DownloaderService';
  try {
    const res = await axios.get(endpoint, {
      params: { url },
      headers: {
        'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36',
        'Referer': 'https://pinterestdownloader.io/'
      },
      timeout: 15000,
      responseType: 'json'
    });
    return res.data;
  } catch (err) {
    if (err.response) {
      const e = new Error(`HTTP ${err.response.status}`);
      e.status = err.response.status;
      e.body = err.response.data;
      throw e;
    }
    throw err;
  }
}
 
module.exports = { pinDown }