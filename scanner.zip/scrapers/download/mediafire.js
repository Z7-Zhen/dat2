const fetch = require("node-fetch");

/**
 * MediaFire Downloader (Stable)
 * @param {string} url - URL MediaFire (contoh: https://www.mediafire.com/file/xxxxxx/file)
 * @returns {Promise<{status: boolean, fileName?: string, downloadUrl?: string, message?: string}>}
 */
async function MediaFire(url) {
  try {
    if (!url || typeof url !== "string") {
      throw new Error("URL MediaFire tidak valid atau kosong.");
    }

    // Step 1: Buat Task ID
    const res1 = await fetch("https://staging-mediafire-direct-url-ui-txd2.frontend.encr.app/api/mediafire/taskid", {
      method: "POST",
      headers: {
        "accept": "application/json",
        "content-type": "application/json",
        "accept-language": "id-ID",
      },
      timeout: 10000, // ⏱️ timeout 10 detik
    });

    const data1 = await res1.json().catch(() => ({}));
    if (!res1.ok || !data1.taskId) {
      throw new Error(`Gagal membuat taskId: ${JSON.stringify(data1)}`);
    }

    const taskId = data1.taskId;

    // Step 2: Kirim URL MediaFire untuk diunduh
    const res2 = await fetch(
      `https://staging-mediafire-direct-url-ui-txd2.frontend.encr.app/api/mediafire/download/${taskId}`,
      {
        method: "POST",
        headers: {
          "accept": "application/json",
          "content-type": "application/json",
          "accept-language": "id-ID",
        },
        body: JSON.stringify({ url }),
        timeout: 20000, // ⏱️ timeout 20 detik
      }
    );

    const data2 = await res2.json().catch(() => ({}));
    if (!res2.ok) {
      throw new Error(`Server error: ${res2.statusText}`);
    }

    // Validasi struktur hasil
    if (!data2 || !data2.downloadUrl || !data2.fileName) {
      throw new Error(`Invalid response format from MediaFire API: ${JSON.stringify(data2)}`);
    }

    // ✅ Return sukses
    return {
      status: true,
      fileName: data2.fileName,
      downloadUrl: data2.downloadUrl,
    };
  } catch (e) {
    console.error("❌ Error MediaFire:", e.message);
    return {
      status: false,
      message: e.message,
    };
  }
}

module.exports = { MediaFire };