const options = {
  name: "Theresa Apis",
  developer: "@Z7:林企业",
  port: 1904,
  webName: "Theresa Playground",
  description: "Rest APIs",
  favicon:
    "https://iili.io/KWpbDJe.jpg",
};

const host = {
  BASE_URL: "http://localhost:1904", // Ganti dengan URL yang sesuai
  // Contoh: https://domain.com
};

module.exports = {
  options,
  host,
};
