const swaggerUi = require("swagger-ui-express");
const config = require("./config");
const { SwaggerTheme, SwaggerThemeNameEnum } = require("swagger-themes");

const theme = new SwaggerTheme();
const customCss = `
  body {
    font-family: 'Poppins', sans-serif;
    margin: 0;
    padding: 0;
    color: #e0e0e0;
    background: linear-gradient(135deg, #0a0a0a, #1a1a1a, #0a0a0a);
    background-size: 400% 400%;
    animation: gradientShift 15s ease infinite;
    overflow-x: hidden;
    min-height: 100vh;
  }

  @keyframes gradientShift {
    0% { background-position: 0% 50%; }
    50% { background-position: 100% 50%; }
    100% { background-position: 0% 50%; }
  }

  .topbar {
    display: none !important;
  }

  .main-container {
    background: rgba(25, 25, 25, 0.85);
    border-radius: 1.5rem;
    box-shadow: 0 15px 30px rgba(0, 0, 0, 0.6);
    overflow: hidden;
    margin-top: 2rem;
    backdrop-filter: blur(15px);
    border: 1px solid rgba(255, 255, 255, 0.1);
    position: relative;
    z-index: 1;
    transition: all 0.3s ease-in-out;
  }

  .main-container::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: radial-gradient(1px 1px at 0 0, #222 1px, transparent 0) 0 0 repeat;
    opacity: 0.05;
    z-index: -1;
  }

  .content {
    background-color: #121212;
    padding: 2.5rem;
    border-radius: 1rem;
    margin-bottom: 1rem;
    max-width: 100%;
    overflow: auto;
  }

  h1 {
    font-size: 3rem;
    font-weight: 700;
    color: #ffffff;
    text-align: center;
    margin-bottom: 1rem;
    background: linear-gradient(to right, #00ff9d, #ff00e6);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    letter-spacing: -1px;
    text-shadow: 0 0 10px rgba(0, 255, 157, 0.3);
    animation: slideInDown 1s ease forwards;
  }

  @keyframes slideInDown {
    from {
      opacity: 0;
      transform: translateY(-30px);
    }
    to {
      opacity: 1;
      transform: translateY(0);
    }
  }

  .tag {
    background: linear-gradient(45deg, #00ff9d, #ff00e6);
    color: white;
    font-weight: 600;
    padding: 0.6rem 1.2rem;
    border-radius: 0.6rem;
    font-size: 0.9rem;
    margin-right: 0.5rem;
    display: inline-block;
    box-shadow: 0 4px 10px rgba(0, 255, 157, 0.3);
    transition: all 0.3s ease;
  }

  .tag:hover {
    transform: scale(1.05);
    box-shadow: 0 6px 15px rgba(0, 255, 157, 0.5);
  }

  .description {
    font-size: 1.1rem;
    color: #b0b0b0;
    line-height: 1.8;
    margin-bottom: 1.5rem;
    max-width: 800px;
    margin-left: auto;
    margin-right: auto;
    text-align: center;
  }

  .operation-wrapper {
    background: rgba(25, 25, 25, 0.8);
    border: 1px solid rgba(255, 255, 255, 0.1);
    border-radius: 1rem;
    margin-bottom: 1.5rem;
    transition: transform 0.3s ease, box-shadow 0.3s ease;
    overflow: hidden;
    backdrop-filter: blur(10px);
    position: relative;
    z-index: 1;
  }

  .operation-wrapper:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 25px rgba(0, 255, 157, 0.2);
  }

  .operation-wrapper::after {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: linear-gradient(45deg, #00ff9d, #ff00e6);
    opacity: 0;
    transition: 0.5s;
    z-index: -1;
  }

  .operation-wrapper:hover::after {
    opacity: 0.1;
  }

  .operation-wrapper .heading {
    background: linear-gradient(45deg, #00ff9d, #ff00e6);
    color: white;
    padding: 1.2rem;
    font-weight: 600;
    font-size: 1.3rem;
    margin-bottom: 0.5rem;
    border-radius: 0.5rem 0.5rem 0 0;
    display: flex;
    justify-content: space-between;
    align-items: center;
  }

  .operation-wrapper .heading span {
    background: rgba(0, 0, 0, 0.4);
    padding: 0.6rem 1rem;
    border-radius: 0.5rem;
    font-size: 0.9rem;
    font-weight: 500;
    transition: all 0.3s ease;
  }

  .operation-wrapper .heading span:hover {
    background: rgba(0, 0, 0, 0.6);
  }

  .operation-wrapper .content {
    padding: 1.8rem;
    background: #1a1a1a;
    border-radius: 0 0 0.5rem 0.5rem;
  }

  .response {
    background: rgba(20, 20, 20, 0.8);
    border-radius: 0.5rem;
    padding: 1.2rem;
    margin: 0.8rem 0;
    border-left: 4px solid #00ff9d;
    transition: all 0.3s ease;
    backdrop-filter: blur(5px);
  }

  .response:hover {
    transform: scale(1.02);
    background: rgba(25, 25, 25, 0.9);
  }

  .response-code {
    font-weight: bold;
    color: #00ff9d;
    font-size: 1.1rem;
  }

  .schema-container {
    background: rgba(25, 25, 25, 0.8);
    border-radius: 0.5rem;
    padding: 1rem;
    margin-top: 1rem;
    font-family: monospace;
    overflow-x: auto;
    max-width: 100%;
    white-space: pre-wrap;
  }

  .schema-key {
    color: #00ff9d;
    font-weight: bold;
  }

  .schema-value {
    color: #e0e0e0;
  }

  .parameter-input {
    background: #2a2a2a;
    border: 1px solid #444;
    color: #ffffff;
    border-radius: 0.5rem;
    padding: 0.8rem 1rem;
    width: 100%;
    margin: 0.8rem 0;
    font-family: monospace;
    transition: all 0.3s ease;
  }

  .parameter-input:focus {
    outline: none;
    border-color: #00ff9d;
    box-shadow: 0 0 10px rgba(0, 255, 157, 0.3);
  }

  .try-out-button {
    background: linear-gradient(45deg, #00ff9d, #ff00e6);
    color: white;
    border: none;
    padding: 0.8rem 1.8rem;
    border-radius: 0.5rem;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s ease;
    margin-top: 1rem;
    font-size: 1rem;
    box-shadow: 0 5px 15px rgba(0, 255, 157, 0.4);
    min-width: 180px;
    text-align: center;
  }

  .try-out-button:hover {
    transform: scale(1.05);
    box-shadow: 0 5px 20px rgba(0, 255, 157, 0.6);
  }

  .try-out-button:active {
    transform: scale(0.98);
  }

  .operation-wrapper.active {
    border: 1px solid #00ff9d;
    animation: neonGlow 2s infinite alternate;
  }

  @keyframes neonGlow {
    from {
      box-shadow: 0 0 10px rgba(0, 255, 157, 0.5);
    }
    to {
      box-shadow: 0 0 20px rgba(0, 255, 157, 0.8);
    }
  }

  @media (max-width: 768px) {
    h1 {
      font-size: 2.2rem;
      margin-bottom: 1rem;
    }
    .operation-wrapper {
      margin-bottom: 1rem;
    }
    .tag {
      font-size: 0.8rem;
      padding: 0.5rem 1rem;
    }
    .description {
      font-size: 1rem;
      margin-bottom: 1rem;
    }
  }

  @media (max-width: 480px) {
    .main-container {
      margin-top: 1rem;
      padding: 0;
    }
    .content {
      padding: 1.5rem;
    }
    h1 {
      font-size: 2rem;
    }
    .try-out-button {
      min-width: 100%;
      margin-top: 1rem;
    }
  }

  .loading {
    animation: pulse 1.5s infinite;
  }

  @keyframes pulse {
    0% { opacity: 0.6; }
    50% { opacity: 1; }
    100% { opacity: 0.6; }
  }

  .schema-container .schema-value {
    font-weight: normal;
    color: #c0c0c0;
  }
`;

const options = {
  customSiteTitle: config.options.webName,
  customfavIcon: config.options.favicon,
  customJs: [
    "https://cdnjs.cloudflare.com/ajax/libs/swagger-ui/4.15.5/swagger-ui-bundle.min.js",
    "https://cdnjs.cloudflare.com/ajax/libs/swagger-ui/4.15.5/swagger-ui-standalone-preset.min.js",
  ],
  customCssUrl: [
    "https://cdnjs.cloudflare.com/ajax/libs/swagger-ui/4.15.5/swagger-ui.min.css",
    "https://cdnjs.cloudflare.com/ajax/libs/swagger-ui/4.15.5/swagger-ui-standalone-preset.min.css",
    "https://cdnjs.cloudflare.com/ajax/libs/swagger-ui/4.15.5/swagger-ui.css",
  ],
  customCss: `${theme.getBuffer(SwaggerThemeNameEnum.DARK)} ${customCss}`,
  swaggerOptions: {
    displayRequestDuration: true,
    defaultModelExpandDepth: 1,
    docExpansion: "list",
    showExtensions: true,
    tryItOutEnabled: true,
    operationsSorter: "alpha",
    tagsSorter: "alpha",
    filter: true,
    layout: "BaseLayout",
    jsonEditor: false,
    oauth2RedirectUrl: null,
  },
};

const swaggerDocument = {
  openapi: "3.0.0",
  info: {
    title: config.options.name,
    description: config.options.description,
    version: "1.0.0",
    "x-logo": {
      url: config.options.favicon,
      altText: config.options.name,
    },
  },
  servers: [
    {
      url: config.host.BASE_URL,
    },
  ],
  tags: [
  {
    name: "Tools",
    description: "API untuk berbagai tools utilitas seperti speedtest, ping, TikTok downloader, dll.",
  },
  {
    name: "Downloader",
    description: "API untuk berbagai downloader utilitas seperti mediafire, spotify TikTok downloader, dll.",
  },
  {
    name: "Anime",
    description: "API untuk berbagai fitur seputar anime seperti jadwal rilis, informasi anime, dan donghua update.",
  },
],
  paths: {
    "/api/tools/ytsummary": {
  post: {
    tags: ["Tools"],
    summary: "YouTube Video Summarizer",
    description:
      "Meringkas isi video YouTube menggunakan API dari [TubeonAI](https://tubeonai.com/web-article-summarizer/).",
    requestBody: {
      required: true,
      content: {
        "application/json": {
          schema: {
            type: "object",
            properties: {
              url: {
                type: "string",
                example: "https://www.youtube.com/watch?v=E7XkLEEYZnE",
                description: "URL video YouTube yang ingin diringkas.",
              },
            },
            required: ["url"],
          },
        },
      },
    },
    responses: {
      200: {
        description: "Berhasil membuat ringkasan dari video YouTube",
        content: {
          "application/json": {
            schema: {
              type: "object",
              properties: {
                status: {
                  type: "boolean",
                  example: true,
                },
                developer: {
                  type: "string",
                  example: config.options.developer,
                },
                result: {
                  type: "object",
                  description: "Hasil ringkasan video dari TubeonAI",
                  properties: {
                    title: {
                      type: "string",
                      example: "AI Revolution Explained",
                    },
                    summary: {
                      type: "string",
                      example:
                        "Video ini membahas dampak revolusi AI terhadap ekonomi, industri, dan kehidupan manusia secara menyeluruh.",
                    },
                    language: {
                      type: "string",
                      example: "en-US",
                    },
                    detail_level: {
                      type: "string",
                      example: "Detailed",
                    },
                  },
                },
              },
            },
          },
        },
      },
      400: {
        description: "Bad Request - URL tidak diisi",
        content: {
          "application/json": {
            schema: {
              type: "object",
              properties: {
                status: {
                  type: "boolean",
                  example: false,
                },
                message: {
                  type: "string",
                  example: "URL YouTube wajib diisi.",
                },
                developer: {
                  type: "string",
                  example: config.options.developer,
                },
              },
            },
          },
        },
      },
      500: {
        description: "Internal Server Error - Gagal memproses ringkasan",
        content: {
          "application/json": {
            schema: {
              type: "object",
              properties: {
                status: {
                  type: "boolean",
                  example: false,
                },
                message: {
                  type: "string",
                  example: "Gagal membuat ringkasan dari TubeonAI.",
                },
                developer: {
                  type: "string",
                  example: config.options.developer,
                },
              },
            },
          },
        },
      },
    },
  },
},
"/api/anime/livechart": {
  "get": {
    "tags": ["Anime"],
    "summary": "Livechart Anime Schedule",
    "description": "Mengambil jadwal update anime dari situs [Livechart.me](https://www.livechart.me/schedule).",
    "parameters": [
      {
        "name": "date",
        "in": "query",
        "description": "Tanggal yang ingin diambil jadwalnya, format YYYY-MM-DD. Jika kosong, gunakan tanggal hari ini.",
        "required": false,
        "schema": {
          "type": "string",
          "example": "2025-10-23"
        }
      }
    ],
    "responses": {
      "200": {
        "description": "Berhasil mendapatkan jadwal anime dari Livechart",
        "content": {
          "application/json": {
            "schema": {
              "type": "object",
              "properties": {
                "status": {
                  "type": "boolean",
                  "example": true
                },
                "developer": {
                  "type": "string",
                  "example": "YourDeveloperName"
                },
                "result": {
                  "type": "array",
                  "description": "Daftar jadwal anime berdasarkan hari",
                  "items": {
                    "type": "object",
                    "properties": {
                      "day": {
                        "type": "string",
                        "example": "Thursday"
                      },
                      "anime": {
                        "type": "array",
                        "items": {
                          "type": "object",
                          "properties": {
                            "title": {
                              "type": "string",
                              "example": "One Piece"
                            },
                            "time": {
                              "type": "string",
                              "example": "00:00"
                            },
                            "eps": {
                              "type": "string",
                              "example": "Ep 1075"
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      },
      "500": {
        "description": "Internal Server Error",
        "content": {
          "application/json": {
            "schema": {
              "type": "object",
              "properties": {
                "status": {
                  "type": "boolean",
                  "example": false
                },
                "message": {
                  "type": "string",
                  "example": "Gagal mengambil data dari Livechart."
                },
                "developer": {
                  "type": "string",
                  "example": "YourDeveloperName"
                }
              }
            }
          }
        }
      }
    }
  }
},
    "/api/anime/anichin": {
  get: {
    tags: ["Anime"],
    summary: "Anichin Donghua Schedule",
    description:
      "Mengambil jadwal update Donghua dari situs [Anichin.watch](https://anichin.watch/schedule/).",
    responses: {
      200: {
        description: "Berhasil mendapatkan jadwal Donghua dari Anichin",
        content: {
          "application/json": {
            schema: {
              type: "object",
              properties: {
                status: {
                  type: "boolean",
                  example: true,
                },
                developer: {
                  type: "string",
                  example: config.options.developer,
                },
                result: {
                  type: "object",
                  properties: {
                    status: {
                      type: "boolean",
                      example: true,
                    },
                    total_days: {
                      type: "integer",
                      example: 7,
                    },
                    schedule: {
                      type: "array",
                      description: "Daftar jadwal Donghua berdasarkan hari.",
                      items: {
                        type: "object",
                        properties: {
                          day: {
                            type: "string",
                            example: "Monday",
                          },
                          donghua: {
                            type: "array",
                            items: {
                              type: "object",
                              properties: {
                                title: {
                                  type: "string",
                                  example: "Perfect World",
                                },
                                img: {
                                  type: "string",
                                  example: "https://anichin.watch/uploads/thumb/perfectworld.jpg",
                                },
                                eps: {
                                  type: "string",
                                  example: "Ep 128",
                                },
                                time: {
                                  type: "string",
                                  example: "18:00",
                                },
                              },
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
          },
        },
      },
      500: {
        description: "Internal Server Error",
        content: {
          "application/json": {
            schema: {
              type: "object",
              properties: {
                status: {
                  type: "boolean",
                  example: false,
                },
                message: {
                  type: "string",
                  example: "Gagal mengambil data dari Anichin.",
                },
                developer: {
                  type: "string",
                  example: config.options.developer,
                },
              },
            },
          },
        },
      },
    },
  },
},
    "/api/tools/enhance-image": {
  post: {
    tags: ["Tools"],
    summary: "Enhance Image (AI Upscale via URL)",
    description: "Meningkatkan kualitas gambar menggunakan AI dari enhanceit.pro melalui URL gambar.",
    requestBody: {
      required: true,
      content: {
        "application/json": {
          schema: {
            type: "object",
            properties: {
              url: {
                type: "string",
                format: "uri",
                description: "URL gambar yang akan ditingkatkan kualitasnya.",
                example: "https://example.com/sample-image.jpg",
              },
            },
            required: ["url"],
          },
        },
      },
    },
    responses: {
      200: {
        description: "Berhasil meningkatkan kualitas gambar",
        content: {
          "application/json": {
            schema: {
              type: "object",
              properties: {
                status: { type: "boolean", example: true },
                developer: { type: "string", example: "Theresa" },
                result: {
                  type: "object",
                  properties: {
                    output_url: {
                      type: "string",
                      example: "https://enhanceit.pro/uploads/output/12345.png",
                    },
                  },
                },
              },
            },
          },
        },
      },
    },
  },
},
    "/api/downloader/tiktok": {
      post: {
        tags: ["Downloader"],
        summary: "Scrape TikTok Video",
        description: "Download data TikTok dari URL yang diberikan.",
        requestBody: {
          required: true,
          content: {
            "application/json": {
              schema: {
                type: "object",
                properties: {
                  url: { type: "string", example: "https://vt.tiktok.com/ZSUMvWufM/" },
                },
                required: ["url"],
              },
            },
          },
        },
        responses: {
          200: {
            description: "Berhasil scrape TikTok",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    status: { type: "boolean", example: true },
                    developer: { type: "string", example: config.options.developer },
                    result: { type: "object", description: "Data TikTok" },
                  },
                },
              },
            },
          },
        },
      },
    },
    "/api/downloader/pinterest": {
  post: {
    tags: ["Downloader"],
    summary: "Scrape Pinterest Media",
    description: "Download media (gambar atau video) dari URL Pinterest yang diberikan.",
    requestBody: {
      required: true,
      content: {
        "application/json": {
          schema: {
            type: "object",
            properties: {
              url: {
                type: "string",
                example: "https://www.pinterest.com/pin/123456789012345678/",
              },
            },
            required: ["url"],
          },
        },
      },
    },
    responses: {
      200: {
        description: "Berhasil scrape Pinterest",
        content: {
          "application/json": {
            schema: {
              type: "object",
              properties: {
                status: { type: "boolean", example: true },
                developer: { type: "string", example: config.options.developer },
                result: {
                  type: "object",
                  description: "Data media Pinterest yang berhasil diambil.",
                  properties: {
                    title: {
                      type: "string",
                      example: "Inspirasi Desain Ruang Tamu Minimalis",
                    },
                    thumbnail: {
                      type: "string",
                      example: "https://i.pinimg.com/originals/ab/cd/ef/abcdef123456.jpg",
                    },
                    media: {
                      type: "array",
                      items: {
                        type: "object",
                        properties: {
                          url: {
                            type: "string",
                            example: "https://pinterest-media-downloader.com/video.mp4",
                          },
                          type: {
                            type: "string",
                            example: "video/mp4",
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
          },
        },
      },
      400: {
        description: "Permintaan tidak valid (URL kosong atau salah format)",
        content: {
          "application/json": {
            schema: {
              type: "object",
              properties: {
                status: { type: "boolean", example: false },
                message: {
                  type: "string",
                  example: "URL wajib diisi atau tidak valid.",
                },
                developer: { type: "string", example: config.options.developer },
              },
            },
          },
        },
      },
      500: {
        description: "Gagal memproses permintaan ke Pinterest",
        content: {
          "application/json": {
            schema: {
              type: "object",
              properties: {
                status: { type: "boolean", example: false },
                message: {
                  type: "string",
                  example: "Internal Server Error saat mengambil data dari Pinterest.",
                },
                developer: { type: "string", example: config.options.developer },
              },
            },
          },
        },
      },
    },
  },
},
    "/api/downloader/mediafire": {
  post: {
    tags: ["Downloader"],
    summary: "Download MediaFire File",
    description: "Mengambil direct download link dari URL MediaFire yang diberikan.",
    requestBody: {
      required: true,
      content: {
        "application/json": {
          schema: {
            type: "object",
            properties: {
              url: {
                type: "string",
                example: "https://www.mediafire.com/file/00jxhpidocee3hg/KHwRS-13-[END]-480p-SAMEHADAKU.CARE.rar/file",
              },
            },
            required: ["url"],
          },
        },
      },
    },
    responses: {
      200: {
        description: "Berhasil mendapatkan link download dari MediaFire",
        content: {
          "application/json": {
            schema: {
              type: "object",
              properties: {
                status: { type: "boolean", example: true },
                developer: { type: "string", example: config.options.developer },
                result: {
                  type: "object",
                  description: "Informasi file MediaFire",
                  properties: {
                    fileName: {
                      type: "string",
                      example: "KHwRS-13-[END]-480p-SAMEHADAKU.CARE.rar",
                    },
                    downloadUrl: {
                      type: "string",
                      example: "https://download.mediafire.com/abcd1234/file.rar",
                    },
                  },
                },
              },
            },
          },
        },
      },
      400: {
        description: "URL MediaFire tidak diberikan atau tidak valid",
        content: {
          "application/json": {
            schema: {
              type: "object",
              properties: {
                status: { type: "boolean", example: false },
                message: { type: "string", example: "URL MediaFire wajib diisi" },
                developer: { type: "string", example: config.options.developer },
              },
            },
          },
        },
      },
      500: {
        description: "Gagal memproses permintaan MediaFire",
        content: {
          "application/json": {
            schema: {
              type: "object",
              properties: {
                status: { type: "boolean", example: false },
                message: {
                  type: "string",
                  example: "Gagal mengambil link download dari MediaFire",
                },
                developer: { type: "string", example: config.options.developer },
              },
            },
          },
        },
      },
    },
  },
},
    "/api/tools/speedtest": {
      get: {
        tags: ["Tools"],
        summary: "Speed Test",
        description: "Uji kecepatan upload, ping ke Google, dan dapatkan informasi lokasi jaringan.",
        responses: {
          200: {
            description: "Hasil uji kecepatan berhasil diperoleh",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    status: {
                      type: "boolean",
                      example: true,
                    },
                    developer: {
                      type: "string",
                      example: config.options.developer,
                    },
                    result: {
                      type: "object",
                      properties: {
                        upload: {
                          type: "string",
                          example: "4.2 Mbps",
                        },
                        ping: {
                          type: "string",
                          example: "89 ms",
                        },
                        server: {
                          type: "string",
                          example: "Jakarta, Jakarta, ID",
                        },
                        provider: {
                          type: "string",
                          example: "PT Telekomunikasi Indonesia",
                        },
                        duration: {
                          type: "string",
                          example: "5.3 sec",
                        },
                        time: {
                          type: "string",
                          example: "01/04/2024 15:30:25",
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          500: {
            description: "Internal Server Error",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    status: {
                      type: "boolean",
                      example: false,
                    },
                    message: {
                      type: "string",
                      example: "Upload test gagal: timeout",
                    },
                    developer: {
                      type: "string",
                      example: config.options.developer,
                    },
                  },
                },
              },
            },
          },
        },
      },
    },
  },
  "x-request-time": new Date().toISOString(),
};

module.exports = { swaggerDocument, options };