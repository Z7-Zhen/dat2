const express = require("express");
const axios = require("axios");
const multer = require("multer");
const path = require("path");
const fetch = require("node-fetch");
const router = express.Router();
const config = require("../schema/config");
const tools = require("../scrapers/tools/tools.js");
const { enhanceImage } = require("../scrapers/tools/enhanceImage");
const { ytsummarize } = require("../scrapers/tools/ytsummary");
const { getDonghuaUpdate } = require("../scrapers/anime/anichin.js");
const { getUpdate } = require("../scrapers/anime/livechart.js");
const { MediaFire } = require("../scrapers/download/mediafire");
const { pinDown } = require("../scrapers/download/pinterest");
const { scrapeTikTok } = require("../scrapers/download/tiktok");
const { developer: dev } = config.options;
const DISCORD_WEBHOOK_URL = process.env.DISCORD_WEBHOOK_URL || "https://discord.com/api/webhooks/1430590953994846239/lfUETG4Gp_bvB_0GMbTAk6fhsCFqgXqPXjC4YbsQRbXT0X9K-RHVrHq56RcAQ18C4Q5z";

if (!DISCORD_WEBHOOK_URL) {
  console.warn("⚠️ Discord webhook not configured. No logs will be sent.");
}

const messages = {
  error: {
    status: 404,
    developer: dev,
    result: "Error, Service Unavailable",
  },
  notRes: {
    status: 404,
    developer: dev,
    result: "Error, Invalid JSON Result",
  },
  query: {
    status: 400,
    developer: dev,
    result: "Please input parameter query!",
  },
  url: {
    status: 400,
    developer: dev,
    result: "Please input parameter URL!",
  },
  notUrl: {
    status: 404,
    developer: dev,
    result: "Error, Invalid URL",
  },
};

const validateQuery = (req, res, next) => {
  const { query } = req.query;
  if (!query) {
    return res.status(messages.query.status).json(messages.query);
  }
  next();
};

const storage = multer.diskStorage({
  destination: "./uploads/",
  filename: (req, file, cb) => {
    cb(null, Date.now() + path.extname(file.originalname));
  },
});

const upload = multer({ storage });

const getRealIp = (req) => {
  const forwarded = req.headers["x-forwarded-for"];
  if (forwarded) {
    return forwarded.split(",")[0].trim(); 
  }

  const socket = req.socket;
  if (socket && socket.remoteAddress) {
    return socket.remoteAddress;
  }

  return req.ip || req.connection.remoteAddress || req.socket.remoteAddress || "unknown";
};

const sendDiscordLog = async (data) => {
  if (!DISCORD_WEBHOOK_URL) return;

  try {
    await axios.post(DISCORD_WEBHOOK_URL, {
      content: null,
      embeds: [
        {
          title: "🔐 API Access Detected",
          color: data.status === "error" ? 0xff0000 : data.status === "success" ? 0x00ff9d : 0x00c7ff,
          fields: [
            { name: "IP Address", value: data.ip, inline: true },
            { name: "Method", value: data.method, inline: true },
            { name: "Endpoint", value: data.endpoint, inline: true },
            { name: "Status", value: data.status, inline: true },
            { name: "Time", value: new Date().toISOString(), inline: true },
          ],
          timestamp: new Date().toISOString(),
          footer: {
            text: `Theresa APIs | ${dev}`,
          },
        },
      ],
    });
  } catch (err) {
    console.error("❌ Failed to send log to Discord:", err.message);
  }
};

const bannedIps = [
  "127.0.0.1",
  "0.0.0.0",
  "localhost",
  "192.168.1.100",
  "192.168.0.1",
  "10.0.0.1",
];

const sanitizeInput = (str) => {
  if (typeof str !== "string") return str;
  return str.replace(/[<>"'&]/g, ""); 
};

router.get("/tools/speedtest", async (req, res) => {
  try {
    const ip = getRealIp(req); 
    const method = req.method;
    const endpoint = req.url;
    const query = sanitizeInput(req.query.query);

    if (bannedIps.includes(ip)) {
      await sendDiscordLog({
        ip,
        method,
        endpoint,
        status: "blocked",
        reason: "Banned IP",
      });
      return res.status(403).json({
        status: false,
        message: "Access denied due to banned IP.",
        developer: dev,
      });
    }

    await sendDiscordLog({
      ip,
      method,
      endpoint,
      status: "request",
      query,
    });

    console.log(`[REQUEST] ${new Date().toISOString()} - ${method} ${endpoint}`);

    if (query && !["upload", "ping"].includes(query)) {
      await sendDiscordLog({
        ip,
        method,
        endpoint,
        status: "invalid_query",
        query,
      });
      return res.status(400).json({
        status: false,
        message: "Invalid query parameter. Use 'upload' or 'ping'.",
        developer: dev,
      });
    }

    const result = await tools.speedtest(query);

    if (!result || typeof result !== "object") {
      throw new Error("Invalid response format from speedtest service");
    }

    res.status(200).json({
      status: true,
      developer: dev,
      result: result,
    });

    await sendDiscordLog({
      ip,
      method,
      endpoint,
      status: "success",
      query,
    });

    console.log(`[SUCCESS] Speed test completed at ${new Date().toISOString()}`);
  } catch (error) {
    console.error(`[ERROR] ${new Date().toISOString()} - ${req.url}:`, error.message);

    const statusCode = error.response?.status || 500;
    const errorMessage = error.message || "Internal Server Error";

    await sendDiscordLog({
      ip,
      method,
      endpoint,
      status: "error",
      error: errorMessage,
    });

    res.status(statusCode).json({
      status: false,
      message: errorMessage,
      developer: dev,
    });
  }
});
router.post("/tools/ytsummary", async (req, res) => {
  const ip = getRealIp(req);
  const method = req.method;
  const endpoint = req.url;

  try {
    console.log(`[REQUEST] ${new Date().toISOString()} - ${method} ${endpoint}`);

    const { url } = req.body;
    if (!url)
      return res.status(400).json({
        status: false,
        message: "URL YouTube wajib diisi",
        developer: dev,
      });

    // 🔒 Cek IP yang diblokir
    if (bannedIps.includes(ip)) {
      await sendDiscordLog({
        ip,
        method,
        endpoint,
        status: "blocked",
        reason: "Banned IP",
      });
      return res.status(403).json({
        status: false,
        message: "Access denied due to banned IP.",
        developer: dev,
      });
    }

    // 📡 Log request masuk
    await sendDiscordLog({
      ip,
      method,
      endpoint,
      status: "request",
      url,
    });

    // 🧠 Import fungsi summarize

    // 🔍 Jalankan summarize
    const result = await ytsummarize(url);

    if (!result || typeof result !== "object") {
      throw new Error("Invalid response format from YouTube summarizer");
    }

    // ✅ Kirim hasil ke client
    res.status(200).json({
      status: true,
      developer: dev,
      result,
    });

    // 🪄 Log sukses ke Discord
    await sendDiscordLog({
      ip,
      method,
      endpoint,
      status: "success",
      url,
    });

    console.log(`[SUCCESS] YouTube summary completed at ${new Date().toISOString()}`);
  } catch (error) {
    console.error(`[ERROR] ${new Date().toISOString()} - ${req.url}:`, error.message);

    const statusCode = error.response?.status || 500;
    const errorMessage = error.message || "Internal Server Error";

    // 🚨 Log error ke Discord
    await sendDiscordLog({
      ip,
      method,
      endpoint,
      status: "error",
      error: errorMessage,
    });

    // ❌ Kirim error ke client
    res.status(statusCode).json({
      status: false,
      message: errorMessage,
      developer: dev,
    });
  }
});
router.post("/downloader/tiktok", async (req, res) => {
  const ip = getRealIp(req);
  const method = req.method;
  const endpoint = req.url;

  try {
    console.log(`[REQUEST] ${new Date().toISOString()} - ${method} ${endpoint}`);

    let { url, query } = req.body;
    url = sanitizeInput(url);

    if (!url) return res.status(messages.url.status).json(messages.url);

    // Cek IP terblokir
    if (bannedIps.includes(ip)) {
      await sendDiscordLog({ ip, method, endpoint, status: "blocked", reason: "Banned IP" });
      return res.status(403).json({
        status: false,
        message: "Access denied due to banned IP.",
        developer: dev,
      });
    }

    // Validasi query jika ada (biar konsisten dengan Speedtest)
    if (query && !["upload", "ping"].includes(query)) {
      await sendDiscordLog({
        ip,
        method,
        endpoint,
        status: "invalid_query",
        query,
      });
      return res.status(400).json({
        status: false,
        message: "Invalid query parameter. Use 'upload' or 'ping'.",
        developer: dev,
      });
    }

    // Kirim log awal ke Discord
    await sendDiscordLog({ ip, method, endpoint, status: "request", url });

    // Jalankan scraper
    const result = await scrapeTikTok(url);

    if (!result || typeof result !== "object") {
      throw new Error("Invalid response format from TikTok scraper");
    }

    // Kirim hasil
    res.status(200).json({
      status: true,
      developer: dev,
      result,
    });

    // Log sukses
    await sendDiscordLog({
      ip,
      method,
      endpoint,
      status: "success",
      url,
      query,
    });

    console.log(`[SUCCESS] TikTok scrape completed at ${new Date().toISOString()}`);
  } catch (error) {
    console.error(`[ERROR] ${new Date().toISOString()} - ${req.url}:`, error.message);

    const statusCode = error.response?.status || 500;
    const errorMessage = error.message || "Internal Server Error";

    await sendDiscordLog({
      ip,
      method,
      endpoint,
      status: "error",
      error: errorMessage,
    });

    res.status(statusCode).json({
      status: false,
      message: errorMessage,
      developer: dev,
    });
  }
});
router.post("/downloader/pinterest", async (req, res) => {
  const ip = getRealIp ? getRealIp(req) : req.ip;
  const method = req.method;
  const endpoint = req.url;

  try {
    console.log(`[REQUEST] ${new Date().toISOString()} - ${method} ${endpoint}`);

    let { url } = req.body;
    url = sanitizeInput ? sanitizeInput(url) : url?.trim();

    if (!url) return res.status(messages.url.status).json(messages.url);

    // 🔒 Cek IP terblokir
    if (bannedIps.includes(ip)) {
      await sendDiscordLog?.({ ip, method, endpoint, status: "blocked", reason: "Banned IP" });
      return res.status(403).json({
        status: false,
        message: "Access denied due to banned IP.",
        developer: dev,
      });
    }

    // 📤 Kirim log awal ke Discord
    await sendDiscordLog?.({ ip, method, endpoint, status: "request", url });

    // 🧠 Jalankan scraper Pinterest
    const result = await pinDown(url);

    if (!result || typeof result !== "object") {
      throw new Error("Invalid response format from Pinterest scraper");
    }

    // ✅ Kirim hasil sukses
    res.status(200).json({
      status: true,
      developer: dev,
      result,
    });

    // 📜 Log sukses
    await sendDiscordLog?.({
      ip,
      method,
      endpoint,
      status: "success",
      url,
    });

    console.log(`[SUCCESS] Pinterest scrape completed at ${new Date().toISOString()}`);
  } catch (error) {
    console.error(`[ERROR] ${new Date().toISOString()} - ${req.url}:`, error.message);

    const statusCode = error.response?.status || 500;
    const errorMessage = error.message || "Internal Server Error";

    await sendDiscordLog?.({
      ip,
      method,
      endpoint,
      status: "error",
      error: errorMessage,
    });

    res.status(statusCode).json({
      status: false,
      message: errorMessage,
      developer: dev,
    });
  }
});
router.post("/downloader/mediafire", async (req, res) => {
  const ip = getRealIp(req);
  const method = req.method;
  const endpoint = req.url;

  try {
    console.log(`[REQUEST] ${new Date().toISOString()} - ${method} ${endpoint}`);

    let { url } = req.body;
    url = sanitizeInput(url);

    if (!url) {
      return res.status(messages.url.status).json(messages.url);
    }

    // 🚫 Cek IP terblokir
    if (bannedIps.includes(ip)) {
      await sendDiscordLog({ ip, method, endpoint, status: "blocked", reason: "Banned IP" });
      return res.status(403).json({
        status: false,
        message: "Access denied due to banned IP.",
        developer: dev,
      });
    }

    // 📡 Kirim log awal ke Discord
    await sendDiscordLog({ ip, method, endpoint, status: "request", url });

    // ⚙️ Jalankan fungsi MediaFire downloader
    const result = await MediaFire(url);

    if (!result || typeof result !== "object") {
      throw new Error("Invalid response format from MediaFire downloader");
    }

    // 📤 Kirim hasil sukses
    res.status(200).json({
      status: true,
      developer: dev,
      result,
    });

    // ✅ Log sukses ke Discord
    await sendDiscordLog({
      ip,
      method,
      endpoint,
      status: "success",
      url,
    });

    console.log(`[SUCCESS] MediaFire download completed at ${new Date().toISOString()}`);
  } catch (error) {
    console.error(`[ERROR] ${new Date().toISOString()} - ${req.url}:`, error.message);

    const statusCode = error.response?.status || 500;
    const errorMessage = error.message || "Internal Server Error";

    await sendDiscordLog({
      ip,
      method,
      endpoint,
      status: "error",
      error: errorMessage,
    });

    res.status(statusCode).json({
      status: false,
      message: errorMessage,
      developer: dev,
    });
  }
});
router.post("/tools/enhance", async (req, res) => {
  try {
    const ip = getRealIp(req);
    const method = req.method;
    const endpoint = req.url;
    const { url } = req.body; // ambil url dari JSON body

    // Validasi URL
    if (!url) {
      return res.status(400).json({
        status: false,
        message: "Parameter 'url' tidak ditemukan.",
        developer: dev,
      });
    }

    console.log(`[REQUEST] ${new Date().toISOString()} - ${method} ${endpoint}`);
    await sendDiscordLog({ ip, method, endpoint, status: "request", url });

    // Jalankan fungsi enhanceImage dengan URL (pastikan fungsi ini support URL)
    const result = await enhanceImage(url);

    if (!result.status) throw new Error(result.message);

    res.status(200).json({
      status: true,
      developer: dev,
      result,
    });

    console.log(`[SUCCESS] Image enhancement (via URL) completed at ${new Date().toISOString()}`);
    await sendDiscordLog({ ip, method, endpoint, status: "success", url });
  } catch (error) {
    console.error(`[ERROR] ${new Date().toISOString()} - ${req.url}:`, error.message);

    await sendDiscordLog({
      ip: getRealIp(req),
      method: req.method,
      endpoint: req.url,
      status: "error",
      error: error.message,
    });

    res.status(500).json({
      status: false,
      message: error.message,
      developer: dev,
    });
  }
});
router.get("/anime/anichin", async (req, res) => {
  try {
    const ip = getRealIp(req);
    const method = req.method;
    const endpoint = req.url;
    const query = sanitizeInput(req.query.query);

    // 🔒 Cek IP yang diblokir
    if (bannedIps.includes(ip)) {
      await sendDiscordLog({
        ip,
        method,
        endpoint,
        status: "blocked",
        reason: "Banned IP",
      });
      return res.status(403).json({
        status: false,
        message: "Access denied due to banned IP.",
        developer: dev,
      });
    }

    // 📡 Log request masuk
    await sendDiscordLog({
      ip,
      method,
      endpoint,
      status: "request",
      query,
    });

    console.log(`[REQUEST] ${new Date().toISOString()} - ${method} ${endpoint}`);

    // 🧠 Import fungsi scraper Anichin

    // 🔍 Jalankan scraper
    const result = await getDonghuaUpdate();

    if (!result || typeof result !== "object") {
      throw new Error("Invalid response format from Anichin scraper");
    }

    // ✅ Kirim hasil ke client
    res.status(200).json({
      status: true,
      developer: dev,
      result,
    });

    // 🪄 Log sukses ke Discord
    await sendDiscordLog({
      ip,
      method,
      endpoint,
      status: "success",
    });

    console.log(`[SUCCESS] Anichin schedule fetched at ${new Date().toISOString()}`);
  } catch (error) {
    console.error(`[ERROR] ${new Date().toISOString()} - ${req.url}:`, error.message);

    const statusCode = error.response?.status || 500;
    const errorMessage = error.message || "Internal Server Error";

    // 🚨 Log error ke Discord
    await sendDiscordLog({
      ip: getRealIp(req),
      method: req.method,
      endpoint: req.url,
      status: "error",
      error: errorMessage,
    });

    // ❌ Kirim error ke client
    res.status(statusCode).json({
      status: false,
      message: errorMessage,
      developer: dev,
    });
  }
});
router.get("/anime/livechart", async (req, res) => {
  try {
    const ip = getRealIp(req);
    const method = req.method;
    const endpoint = req.url;
    const date = sanitizeInput(req.query.date); // bisa kirim ?date=YYYY-MM-DD

    // 🔒 Cek IP yang diblokir
    if (bannedIps.includes(ip)) {
      await sendDiscordLog({
        ip,
        method,
        endpoint,
        status: "blocked",
        reason: "Banned IP",
      });
      return res.status(403).json({
        status: false,
        message: "Access denied due to banned IP.",
        developer: dev,
      });
    }

    // 📡 Log request masuk
    await sendDiscordLog({
      ip,
      method,
      endpoint,
      status: "request",
      query: date,
    });

    console.log(`[REQUEST] ${new Date().toISOString()} - ${method} ${endpoint}`);

    // 🔍 Jalankan scraper Livechart
    const result = await getUpdate(date);

    if (!result || !Array.isArray(result)) {
      throw new Error("Invalid response format from Livechart scraper");
    }

    // ✅ Kirim hasil ke client
    res.status(200).json({
      status: true,
      developer: dev,
      result,
    });

    // 🪄 Log sukses ke Discord
    await sendDiscordLog({
      ip,
      method,
      endpoint,
      status: "success",
    });

    console.log(`[SUCCESS] Livechart schedule fetched at ${new Date().toISOString()}`);
  } catch (error) {
    console.error(`[ERROR] ${new Date().toISOString()} - ${req.url}:`, error.message);

    const statusCode = error.response?.status || 500;
    const errorMessage = error.message || "Internal Server Error";

    // 🚨 Log error ke Discord
    await sendDiscordLog({
      ip: getRealIp(req),
      method: req.method,
      endpoint: req.url,
      status: "error",
      error: errorMessage,
    });

    // ❌ Kirim error ke client
    res.status(statusCode).json({
      status: false,
      message: errorMessage,
      developer: dev,
    });
  }
});
router.get("/health", (req, res) => {
  res.status(200).json({
    status: "OK",
    timestamp: new Date().toISOString(),
    service: "API Gateway",
    uptime: process.uptime(),
  });
});

router.use("*", (req, res) => {
  res.status(404).json({
    status: false,
    message: "Endpoint not found",
    developer: dev,
  });
});

module.exports = router;
